package com.example.beansbay_no_font.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.beansbay_no_font.data.Product
import com.example.beansbay_no_font.data.dataProductDummy
import com.example.beansbay_no_font.data.getDummyProduct

class MainActivityViewModel : ViewModel() {
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading = _isLoading



    private val _spotProduct = MutableLiveData<List<Product>>()
    val spotProduct = _spotProduct


    fun getSpotlightedProduct(){
//TODO
//        panggil api spotlighted product disini
        _spotProduct.value = getDummyProduct()
    }

    private val _recProduct = MutableLiveData<List<Product>>()
    val recProduct = _recProduct

    fun getRecommendedProduct(){
//TODO
//        panggil api recommended product disini
        _recProduct.value = getDummyProduct()
    }


}