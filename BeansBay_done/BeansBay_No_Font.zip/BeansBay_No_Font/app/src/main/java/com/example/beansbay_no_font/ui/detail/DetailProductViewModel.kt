package com.example.beansbay_no_font.ui.detail

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.beansbay_no_font.data.Product
import com.example.beansbay_no_font.data.Review
import com.example.beansbay_no_font.data.getDummyProduct
import com.example.beansbay_no_font.data.getDummyReview

class DetailProductViewModel : ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading = _isLoading

    private val _detailedProduct = MutableLiveData<Product>()
    val detailedProduct = _detailedProduct

    private val _reviewProduct = MutableLiveData<List<Review>>()
    val reviewProduct = _reviewProduct

    private val _recProduct = MutableLiveData<List<Product>>()
    val recProduct = _recProduct

    fun getRecommendedProduct(){
//TODO
//  panggil api recommended product disini
        _recProduct.value = getDummyProduct()
    }

    fun getProductDetail(){
//TODO
//  panggil api untuk ngeset data detail di halaman detail

        val dummy = Product(
            "1",
            "Kopi Surabaya",
            "Rumah Kopi",
            10000,
            "Kopi dengan ciri khas surabaya yang memiliki rasa yang harum dan tajam"
        )
        _detailedProduct.value = dummy
    }

    fun getProductReview(id: String){
//TODO
//   panggil api review produk berdasarkan id produk
//   sementara pakek dummy dulu
        _reviewProduct.value = getDummyReview()
    }

}