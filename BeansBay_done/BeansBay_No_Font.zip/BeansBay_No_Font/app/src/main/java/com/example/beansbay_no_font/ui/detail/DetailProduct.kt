package com.example.beansbay_no_font.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.beansbay_no_font.adapter.ProductAdapter
import com.example.beansbay_no_font.adapter.ReviewAdapter
import com.example.beansbay_no_font.data.Product
import com.example.beansbay_no_font.data.Review

import com.example.beansbay_no_font.databinding.ActivityDetailProductBinding

class DetailProduct : AppCompatActivity() {

    private val detailProductViewModel by viewModels<DetailProductViewModel>()
    private lateinit var binding : ActivityDetailProductBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.rvReview.layoutManager =
            LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL,
                false)
        binding.rvRecProduct.layoutManager =
            LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL,
                false)

//TODO 
//        get data detail dari api, pake keyword yang dikirim dari intent dari home activity
//        kalau udah dipanggil masing-masing view di set text

//        di observe tiap variabel terus diset dibawah
//        dibawah ini masih pakek data dummy

        detailProductViewModel.getProductDetail()

        detailProductViewModel.detailedProduct.observe(this){
            binding.namaProduk.text = it.nama
            Glide.with(binding.fotoProduk)
                .load("https://images.tokopedia.net/img/cache/700/product-1/2018/6/23/748434/748434_1c873fe5-4881-43e3-9c2d-5f8c4ba69e41_700_715.jpg")
                .into(binding.fotoProduk)
            binding.namaTokoProduk.text = it.toko
            binding.hargaProduk.text = it.harga.toString()
            binding.deskripsiProduk.text = it.deskripsi
            detailProductViewModel.getProductReview(it.id)
        }

        detailProductViewModel.reviewProduct.observe(this){
            setReviewProduct(it)
        }

        detailProductViewModel.getRecommendedProduct()
        detailProductViewModel.recProduct.observe(this){
            setRecProduct(it)
        }
    }

    private fun setRecProduct(listProduct : List<Product>){
        binding.rvRecProduct.adapter = ProductAdapter(listProduct)
    }

    private fun setReviewProduct(listReview : List<Review>){
        binding.rvReview.adapter = ReviewAdapter(listReview)
    }
}