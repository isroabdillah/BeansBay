package com.example.beansbay_no_font.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.beansbay_no_font.data.Product
import com.example.beansbay_no_font.R

class SpotlightProductAdapter(private val listProduct : List<Product>):RecyclerView.Adapter<SpotlightProductAdapter.ViewHolder>() {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvProductName :TextView = view.findViewById(R.id.nama_produk_spotlight)
        val tvProductPrice : TextView = view.findViewById(R.id.harga_produk_spotlight)
        val tvProductStore : TextView = view.findViewById(R.id.nama_toko_spotlight)
        val ivProductPhoto : ImageView = view.findViewById(R.id.foto_produk_spotlight)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_product_spotlight, parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvProductName.text = listProduct[position].nama
        holder.tvProductPrice.text = listProduct[position].harga.toString()
        holder.tvProductStore.text = listProduct[position].toko

        Glide.with(holder.itemView.context)
            .load("https://images.tokopedia.net/img/cache/700/product-1/2018/6/23/748434/748434_1c873fe5-4881-43e3-9c2d-5f8c4ba69e41_700_715.jpg")
            .into(holder.ivProductPhoto)

    }

    override fun getItemCount(): Int = listProduct.size
}