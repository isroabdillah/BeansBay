package com.example.beansbay_no_font.ui.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.beansbay_no_font.adapter.ProductAdapter
import com.example.beansbay_no_font.data.Product
import com.example.beansbay_no_font.adapter.SpotlightProductAdapter
import com.example.beansbay_no_font.databinding.ActivityMainBinding
import com.example.beansbay_no_font.setting.DarkModeActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    private val mainViewModel by viewModels<MainActivityViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.searchBar.setOnClickListener{
            startActivity(Intent(this, DarkModeActivity::class.java ))
        }

        binding.rvSpotlightProduct.layoutManager =
            LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL,
                false)
        binding.rvRecProduct.layoutManager =
            LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL,
                false)

        mainViewModel.getRecommendedProduct()
        mainViewModel.getSpotlightedProduct()
        mainViewModel.spotProduct.observe(this){
            setSpotProduct(it)
        }
        mainViewModel.recProduct.observe(this){
            setRecProduct(it)
        }
    }

    private fun setRecProduct(listProduct : List<Product>){
        binding.rvRecProduct.adapter = ProductAdapter(listProduct)
    }

    private fun setSpotProduct(listProduct: List<Product>){
        binding.rvSpotlightProduct.adapter = SpotlightProductAdapter(listProduct)
    }
}