package com.example.beansbay_no_font.ui.checkout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.beansbay_no_font.R
import com.example.beansbay_no_font.databinding.ActivityCheckoutBinding
import com.example.beansbay_no_font.databinding.ActivityLoginBinding

class CheckoutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCheckoutBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        supportActionBar?.hide()


        super.onCreate(savedInstanceState)
        binding = ActivityCheckoutBinding.inflate(layoutInflater)

    }
}